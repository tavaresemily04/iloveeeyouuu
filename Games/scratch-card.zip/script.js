const canvas = document.getElementById("scratchCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 300;
canvas.height = 150;

let isDrawing = false;

function setupCanvas() {
  ctx.fillStyle = "#c0c0c0"; // gray scratch texture
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.globalCompositeOperation = "destination-out";
}

canvas.addEventListener("mousedown", () => { isDrawing = true; });
canvas.addEventListener("mouseup", () => { isDrawing = false; });
canvas.addEventListener("mousemove", draw);
canvas.addEventListener("touchstart", () => { isDrawing = true; });
canvas.addEventListener("touchend", () => { isDrawing = false; });
canvas.addEventListener("touchmove", drawTouch);

function draw(e) {
  if (!isDrawing) return;
  ctx.beginPath();
  ctx.arc(e.offsetX, e.offsetY, 15, 0, Math.PI * 2);
  ctx.fill();
}

function drawTouch(e) {
  const rect = canvas.getBoundingClientRect();
  const touch = e.touches[0];
  const x = touch.clientX - rect.left;
  const y = touch.clientY - rect.top;
  ctx.beginPath();
  ctx.arc(x, y, 15, 0, Math.PI * 2);
  ctx.fill();
  e.preventDefault();
}

setupCanvas();
